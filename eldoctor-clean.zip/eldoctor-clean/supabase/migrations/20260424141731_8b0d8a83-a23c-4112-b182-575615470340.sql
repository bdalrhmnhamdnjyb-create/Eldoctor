CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'editor');
CREATE TYPE public.article_status AS ENUM ('draft', 'published');
CREATE TYPE public.article_kind AS ENUM ('news', 'opinion', 'design', 'media');

CREATE TABLE public.user_roles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

CREATE OR REPLACE FUNCTION public.has_any_role(_user_id UUID, _roles public.app_role[])
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = ANY(_roles)
  )
$$;

CREATE POLICY "Users can view their own roles"
ON public.user_roles
FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can add roles"
ON public.user_roles
FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update roles"
ON public.user_roles
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can remove roles"
ON public.user_roles
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL DEFAULT '',
  kind public.article_kind NOT NULL DEFAULT 'news',
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT categories_name_length CHECK (char_length(name) BETWEEN 2 AND 80),
  CONSTRAINT categories_slug_format CHECK (slug ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$')
);

CREATE TABLE public.tags (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT tags_name_length CHECK (char_length(name) BETWEEN 2 AND 60),
  CONSTRAINT tags_slug_format CHECK (slug ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$')
);

CREATE TABLE public.articles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  author_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  category_id UUID NOT NULL REFERENCES public.categories(id) ON DELETE RESTRICT,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  excerpt TEXT NOT NULL DEFAULT '',
  content TEXT NOT NULL DEFAULT '',
  cover_image_url TEXT,
  video_url TEXT,
  status public.article_status NOT NULL DEFAULT 'draft',
  is_featured BOOLEAN NOT NULL DEFAULT false,
  published_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT articles_title_length CHECK (char_length(title) BETWEEN 5 AND 160),
  CONSTRAINT articles_slug_format CHECK (slug ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$'),
  CONSTRAINT articles_excerpt_length CHECK (char_length(excerpt) <= 320),
  CONSTRAINT articles_content_length CHECK (char_length(content) <= 60000),
  CONSTRAINT articles_video_url_length CHECK (video_url IS NULL OR char_length(video_url) <= 600),
  CONSTRAINT articles_cover_url_length CHECK (cover_image_url IS NULL OR char_length(cover_image_url) <= 1000)
);

CREATE TABLE public.article_tags (
  article_id UUID NOT NULL REFERENCES public.articles(id) ON DELETE CASCADE,
  tag_id UUID NOT NULL REFERENCES public.tags(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (article_id, tag_id)
);

ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.article_tags ENABLE ROW LEVEL SECURITY;

CREATE INDEX idx_articles_status_published_at ON public.articles(status, published_at DESC);
CREATE INDEX idx_articles_category_id ON public.articles(category_id);
CREATE INDEX idx_articles_author_id ON public.articles(author_id);
CREATE INDEX idx_articles_featured ON public.articles(is_featured) WHERE is_featured = true;
CREATE INDEX idx_article_tags_tag_id ON public.article_tags(tag_id);

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.set_published_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF NEW.status = 'published' AND NEW.published_at IS NULL THEN
    NEW.published_at = now();
  END IF;
  IF NEW.status = 'draft' THEN
    NEW.published_at = NULL;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_categories_updated_at
BEFORE UPDATE ON public.categories
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_articles_updated_at
BEFORE UPDATE ON public.articles
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER set_articles_published_at
BEFORE INSERT OR UPDATE ON public.articles
FOR EACH ROW
EXECUTE FUNCTION public.set_published_at();

CREATE POLICY "Everyone can view categories"
ON public.categories
FOR SELECT
USING (true);

CREATE POLICY "Admins and moderators can create categories"
ON public.categories
FOR INSERT
TO authenticated
WITH CHECK (public.has_any_role(auth.uid(), ARRAY['admin', 'moderator']::public.app_role[]));

CREATE POLICY "Admins and moderators can update categories"
ON public.categories
FOR UPDATE
TO authenticated
USING (public.has_any_role(auth.uid(), ARRAY['admin', 'moderator']::public.app_role[]))
WITH CHECK (public.has_any_role(auth.uid(), ARRAY['admin', 'moderator']::public.app_role[]));

CREATE POLICY "Admins can delete categories"
ON public.categories
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Everyone can view tags"
ON public.tags
FOR SELECT
USING (true);

CREATE POLICY "Team can create tags"
ON public.tags
FOR INSERT
TO authenticated
WITH CHECK (public.has_any_role(auth.uid(), ARRAY['admin', 'moderator', 'editor']::public.app_role[]));

CREATE POLICY "Admins and moderators can update tags"
ON public.tags
FOR UPDATE
TO authenticated
USING (public.has_any_role(auth.uid(), ARRAY['admin', 'moderator']::public.app_role[]))
WITH CHECK (public.has_any_role(auth.uid(), ARRAY['admin', 'moderator']::public.app_role[]));

CREATE POLICY "Admins can delete tags"
ON public.tags
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Visitors can view published articles"
ON public.articles
FOR SELECT
USING (status = 'published' OR public.has_any_role(auth.uid(), ARRAY['admin', 'moderator']::public.app_role[]) OR author_id = auth.uid());

CREATE POLICY "Team can create articles"
ON public.articles
FOR INSERT
TO authenticated
WITH CHECK (
  author_id = auth.uid()
  AND public.has_any_role(auth.uid(), ARRAY['admin', 'moderator', 'editor']::public.app_role[])
);

CREATE POLICY "Team can update permitted articles"
ON public.articles
FOR UPDATE
TO authenticated
USING (
  public.has_any_role(auth.uid(), ARRAY['admin', 'moderator']::public.app_role[])
  OR author_id = auth.uid()
)
WITH CHECK (
  public.has_any_role(auth.uid(), ARRAY['admin', 'moderator']::public.app_role[])
  OR author_id = auth.uid()
);

CREATE POLICY "Team can delete permitted articles"
ON public.articles
FOR DELETE
TO authenticated
USING (
  public.has_any_role(auth.uid(), ARRAY['admin', 'moderator']::public.app_role[])
  OR author_id = auth.uid()
);

CREATE POLICY "Everyone can view tags on published articles"
ON public.article_tags
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.articles
    WHERE articles.id = article_tags.article_id
      AND (
        articles.status = 'published'
        OR public.has_any_role(auth.uid(), ARRAY['admin', 'moderator']::public.app_role[])
        OR articles.author_id = auth.uid()
      )
  )
);

CREATE POLICY "Team can add article tags"
ON public.article_tags
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.articles
    WHERE articles.id = article_tags.article_id
      AND (
        public.has_any_role(auth.uid(), ARRAY['admin', 'moderator']::public.app_role[])
        OR articles.author_id = auth.uid()
      )
  )
);

CREATE POLICY "Team can remove article tags"
ON public.article_tags
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.articles
    WHERE articles.id = article_tags.article_id
      AND (
        public.has_any_role(auth.uid(), ARRAY['admin', 'moderator']::public.app_role[])
        OR articles.author_id = auth.uid()
      )
  )
);

INSERT INTO public.categories (name, slug, description, kind, sort_order) VALUES
('أخبار عامة', 'general-news', 'متابعة الأخبار والموضوعات العامة لحظة بلحظة.', 'news', 1),
('مقالات وآراء', 'articles-opinions', 'رؤى وتحليلات ومقالات رأي بقلم فريق المجلة.', 'opinion', 2),
('تصميم وإبداع', 'design-creativity', 'مساحة للأفكار الإبداعية والتصميم والفنون البصرية.', 'design', 3),
('فيديو وصور', 'video-photo', 'مواد مرئية ومعارض صور وروابط فيديو مختارة.', 'media', 4);

INSERT INTO public.tags (name, slug) VALUES
('عاجل', 'breaking'),
('رأي', 'opinion'),
('تصميم', 'design'),
('فيديو', 'video');

INSERT INTO storage.buckets (id, name, public)
VALUES ('article-media', 'article-media', true);

CREATE POLICY "Article media is publicly visible"
ON storage.objects
FOR SELECT
USING (bucket_id = 'article-media');

CREATE POLICY "Team can upload article media"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'article-media'
  AND public.has_any_role(auth.uid(), ARRAY['admin', 'moderator', 'editor']::public.app_role[])
);

CREATE POLICY "Team can update article media"
ON storage.objects
FOR UPDATE
TO authenticated
USING (
  bucket_id = 'article-media'
  AND public.has_any_role(auth.uid(), ARRAY['admin', 'moderator', 'editor']::public.app_role[])
)
WITH CHECK (
  bucket_id = 'article-media'
  AND public.has_any_role(auth.uid(), ARRAY['admin', 'moderator', 'editor']::public.app_role[])
);

CREATE POLICY "Team can delete article media"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'article-media'
  AND public.has_any_role(auth.uid(), ARRAY['admin', 'moderator']::public.app_role[])
);