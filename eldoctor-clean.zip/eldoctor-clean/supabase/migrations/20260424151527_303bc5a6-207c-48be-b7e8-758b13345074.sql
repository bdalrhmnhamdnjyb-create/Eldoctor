CREATE TABLE IF NOT EXISTS public.admin_access_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  display_name TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  requested_role public.app_role NOT NULL DEFAULT 'editor',
  status TEXT NOT NULL DEFAULT 'pending',
  reviewed_by UUID,
  reviewed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.admin_access_requests ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'admin_access_requests'
      AND policyname = 'Users can view own requests and admins can view all'
  ) THEN
    CREATE POLICY "Users can view own requests and admins can view all"
    ON public.admin_access_requests
    FOR SELECT
    USING ((auth.uid() = user_id) OR public.has_role(auth.uid(), 'admin'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'admin_access_requests'
      AND policyname = 'Users can create own pending requests'
  ) THEN
    CREATE POLICY "Users can create own pending requests"
    ON public.admin_access_requests
    FOR INSERT
    TO authenticated
    WITH CHECK ((auth.uid() = user_id) AND (status = 'pending'));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'admin_access_requests'
      AND policyname = 'Admins can update requests'
  ) THEN
    CREATE POLICY "Admins can update requests"
    ON public.admin_access_requests
    FOR UPDATE
    TO authenticated
    USING (public.has_role(auth.uid(), 'admin'))
    WITH CHECK (public.has_role(auth.uid(), 'admin'));
  END IF;
END $$;

CREATE TRIGGER update_admin_access_requests_updated_at
BEFORE UPDATE ON public.admin_access_requests
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.is_first_admin_candidate()
RETURNS boolean
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  candidate_email text;
  candidate_name text;
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN false;
  END IF;

  SELECT
    lower(coalesce(email, '')),
    lower(coalesce(raw_user_meta_data->>'full_name', raw_user_meta_data->>'name', ''))
  INTO candidate_email, candidate_name
  FROM auth.users
  WHERE id = auth.uid();

  RETURN candidate_name LIKE '%عبدالرحمن%'
    OR candidate_name LIKE '%عبد الرحمن%'
    OR candidate_email LIKE 'abdulrahman%'
    OR candidate_email LIKE 'abdelrahman%'
    OR candidate_email LIKE 'abd%';
END;
$$;

CREATE OR REPLACE FUNCTION public.claim_first_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN false;
  END IF;

  IF EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'admin') THEN
    RETURN false;
  END IF;

  IF NOT public.is_first_admin_candidate() THEN
    RETURN false;
  END IF;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (auth.uid(), 'admin')
  ON CONFLICT (user_id, role) DO NOTHING;

  RETURN true;
END;
$$;

CREATE OR REPLACE FUNCTION public.approve_admin_access_request(_request_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  target_request public.admin_access_requests%ROWTYPE;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RETURN false;
  END IF;

  SELECT * INTO target_request
  FROM public.admin_access_requests
  WHERE id = _request_id AND status = 'pending';

  IF NOT FOUND THEN
    RETURN false;
  END IF;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (target_request.user_id, target_request.requested_role)
  ON CONFLICT (user_id, role) DO NOTHING;

  UPDATE public.admin_access_requests
  SET status = 'approved', reviewed_by = auth.uid(), reviewed_at = now()
  WHERE id = _request_id;

  RETURN true;
END;
$$;