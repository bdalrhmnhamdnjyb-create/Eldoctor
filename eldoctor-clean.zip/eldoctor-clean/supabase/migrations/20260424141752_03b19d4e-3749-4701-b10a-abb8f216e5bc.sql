UPDATE storage.buckets
SET public = false
WHERE id = 'article-media';

DROP POLICY IF EXISTS "Article media is publicly visible" ON storage.objects;