CREATE POLICY "Article media can be read for display"
ON storage.objects
FOR SELECT
USING (bucket_id = 'article-media');