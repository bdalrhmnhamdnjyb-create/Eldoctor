import { Link } from "@tanstack/react-router";
import { Menu, Search } from "lucide-react";
import { useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import logo from "@/assets/dr-ahmed-logo.jpg";

const navItems = [
  { to: "/", label: "الرئيسية" },
  { to: "/articles", label: "كل المقالات" },
  { to: "/categories/$slug", params: { slug: "general-news" }, label: "أخبار عامة" },
  { to: "/categories/$slug", params: { slug: "design-creativity" }, label: "تصميم وإبداع" },
  { to: "/about", label: "من نحن" },
] as const;

export function SiteLayout({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background text-foreground" dir="rtl">
      <header className="sticky top-0 z-40 border-b border-border/70 bg-background/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
          <Link to="/" className="flex min-w-0 items-center gap-3">
            <img src={logo} alt="شعار الدكتور نيوز" className="h-12 w-12 rounded-md border border-border object-cover" />
            <div className="min-w-0">
              <p className="text-xs text-primary">أخبار ومقالات</p>
              <p className="truncate text-base font-bold sm:text-lg">الدكتور نيوز</p>
            </div>
          </Link>

          <nav className="hidden items-center gap-1 lg:flex">
            {navItems.map((item) => (
              <Link
                key={item.label}
                to={item.to}
                params={"params" in item ? item.params : undefined}
                activeProps={{ className: "bg-secondary text-primary" }}
                className="rounded-md px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="hidden items-center gap-2 sm:flex">
            <Button variant="ghost" size="icon" asChild aria-label="بحث">
              <Link to="/search"><Search /></Link>
            </Button>
          </div>

          <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setOpen((value) => !value)} aria-label="القائمة">
            <Menu />
          </Button>
        </div>

        {open && (
          <div className="border-t border-border px-4 py-3 lg:hidden">
            <nav className="grid gap-2">
              {navItems.map((item) => (
                <Link
                  key={item.label}
                  to={item.to}
                  params={"params" in item ? item.params : undefined}
                  onClick={() => setOpen(false)}
                  className="rounded-md bg-secondary px-3 py-2 text-sm"
                >
                  {item.label}
                </Link>
              ))}
              <Link to="/search" onClick={() => setOpen(false)} className="rounded-md bg-secondary px-3 py-2 text-sm">البحث</Link>
            </nav>
          </div>
        )}
      </header>

      <main>{children}</main>

      <footer className="border-t border-border bg-card">
        <div className="mx-auto grid max-w-7xl gap-6 px-4 py-8 sm:px-6 lg:grid-cols-[1fr_auto] lg:px-8">
          <div>
            <p className="text-lg font-bold">الدكتور نيوز</p>
            <p className="mt-2 max-w-2xl text-sm leading-7 text-muted-foreground">
              موقع عربي للأخبار والمقالات والتصميم والمحتوى المرئي، بإدارة تحريرية موثوقة.
            </p>
          </div>
          <Link to="/admin" className="text-sm text-muted-foreground transition-colors hover:text-primary">© {new Date().getFullYear()} جميع الحقوق محفوظة</Link>
        </div>
      </footer>
    </div>
  );
}
