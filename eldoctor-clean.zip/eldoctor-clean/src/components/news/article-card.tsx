import { Link } from "@tanstack/react-router";
import { CalendarDays } from "lucide-react";
import type { Article } from "@/lib/news";
import { formatArabicDate } from "@/lib/news";

type ArticleCardProps = {
  article: Article;
  imageUrl?: string | null;
  featured?: boolean;
};

export function ArticleCard({ article, imageUrl, featured = false }: ArticleCardProps) {
  return (
    <Link to="/articles/$slug" params={{ slug: article.slug }} className="group block">
      <article className={featured ? "grid gap-5 overflow-hidden border-b border-border pb-6 transition-colors hover:border-primary/60 lg:grid-cols-[1.15fr_0.85fr]" : "overflow-hidden border-b border-border pb-5 transition-colors hover:border-primary/60"}>
        <div className="aspect-[16/10] overflow-hidden rounded-md bg-secondary">
          {imageUrl ? (
            <img src={imageUrl} alt={article.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
          ) : (
            <div className="flex h-full items-center justify-center bg-[linear-gradient(135deg,var(--card),var(--secondary))] px-4 text-center text-sm text-muted-foreground">
              الدكتور نيوز
            </div>
          )}
        </div>
      <div className={featured ? "flex flex-col justify-center" : "mt-4"}>
        <div className="mb-3 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          <span className="rounded-sm bg-primary px-2 py-1 font-medium text-primary-foreground">{article.categories?.name ?? "مقال"}</span>
          <span className="inline-flex items-center gap-1"><CalendarDays className="h-3.5 w-3.5" />{formatArabicDate(article.published_at ?? article.created_at)}</span>
        </div>
        <h2 className={featured ? "text-2xl font-bold leading-tight transition-colors group-hover:text-primary sm:text-4xl" : "text-xl font-bold leading-snug transition-colors group-hover:text-primary"}>{article.title}</h2>
        <p className="mt-3 line-clamp-3 text-sm leading-7 text-muted-foreground">{article.excerpt || article.content}</p>
      </div>
      </article>
    </Link>
  );
}
