import { useEffect, useMemo, useState } from "react";

const PETAL_COUNT = 28;
const PETAL_EMOJIS = ["🌹", "🌸", "🌺", "🌷", "❀"];

type Petal = {
  id: number;
  left: number;
  delay: number;
  duration: number;
  size: number;
  rotate: number;
  emoji: string;
};

export function WelcomeOverlay() {
  const [visible, setVisible] = useState(false);
  const [fading, setFading] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (sessionStorage.getItem("welcome-shown") === "1") return;

    sessionStorage.setItem("welcome-shown", "1");
    setVisible(true);

    const fadeTimer = setTimeout(() => setFading(true), 3500);
    const removeTimer = setTimeout(() => setVisible(false), 4500);

    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(removeTimer);
    };
  }, []);

  const petals = useMemo<Petal[]>(() => {
    return Array.from({ length: PETAL_COUNT }, (_, index) => ({
      id: index,
      left: Math.random() * 100,
      delay: Math.random() * 1.5,
      duration: 4 + Math.random() * 3,
      size: 18 + Math.random() * 22,
      rotate: Math.random() * 360,
      emoji: PETAL_EMOJIS[Math.floor(Math.random() * PETAL_EMOJIS.length)],
    }));
  }, []);

  if (!visible) return null;

  return (
    <div
      aria-hidden="true"
      className={`pointer-events-none fixed inset-0 z-[100] overflow-hidden transition-opacity duration-1000 ${
        fading ? "opacity-0" : "opacity-100"
      }`}
    >
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-transparent to-transparent backdrop-blur-[1px]" />

      {petals.map((petal) => (
        <span
          key={petal.id}
          className="welcome-petal absolute -top-10 select-none"
          style={{
            left: `${petal.left}%`,
            fontSize: `${petal.size}px`,
            animationDelay: `${petal.delay}s`,
            animationDuration: `${petal.duration}s`,
            transform: `rotate(${petal.rotate}deg)`,
          }}
        >
          {petal.emoji}
        </span>
      ))}

      <div className="absolute inset-0 flex items-center justify-center px-4">
        <div className="welcome-card pointer-events-none rounded-2xl border border-primary/30 bg-card/90 px-8 py-6 text-center shadow-[var(--shadow-elegant)] backdrop-blur-md">
          <p className="text-sm text-primary">أهلاً بك</p>
          <h2 className="mt-1 text-2xl font-extrabold sm:text-3xl">مرحباً بك في الدكتور نيوز</h2>
          <p className="mt-2 text-sm text-muted-foreground">نتمنى لك قراءة ممتعة 🌹</p>
        </div>
      </div>
    </div>
  );
}
