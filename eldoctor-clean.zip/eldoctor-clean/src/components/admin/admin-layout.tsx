import { Link, useRouter } from "@tanstack/react-router";
import { FileText, Home, LogOut, Plus, Shield, Users } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";

export function AdminLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const { user, loading, isTeamMember, isAdmin, canClaimFirstAdmin, claimFirstAdmin, signOut } = useAuth();

  if (loading) {
    return <div className="flex min-h-screen items-center justify-center bg-background text-foreground" dir="rtl">جاري التحميل...</div>;
  }

  if (!user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background px-4 text-foreground" dir="rtl">
        <div className="max-w-md text-center">
          <Shield className="mx-auto mb-4 h-12 w-12 text-primary" />
          <h1 className="text-2xl font-bold">لوحة الإدارة محمية</h1>
          <p className="mt-2 text-sm text-muted-foreground">سجّل الدخول لإدارة الأخبار والمقالات.</p>
          <Button className="mt-6" asChild><Link to="/login">تسجيل الدخول</Link></Button>
        </div>
      </div>
    );
  }

  if (!isTeamMember) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background px-4 text-foreground" dir="rtl">
        <div className="max-w-lg text-center">
          <Shield className="mx-auto mb-4 h-12 w-12 text-primary" />
          <h1 className="text-2xl font-bold">طلب دخول الإدارة</h1>
          <p className="mt-2 text-sm leading-7 text-muted-foreground">{canClaimFirstAdmin ? "أنت عبدالرحمن المدير؟ اضغط تأكيد لتفعيل حسابك كمدير." : "حسابك غير مصرح له بعد. سجّل طلبك وانتظر موافقة المدير."}</p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            {canClaimFirstAdmin && <Button onClick={async () => { await claimFirstAdmin(); router.invalidate(); }}>أيوه أنا عبدالرحمن المدير</Button>}
            {!canClaimFirstAdmin && <Button asChild><Link to="/admin/access-request">طلب موافقة</Link></Button>}
            <Button variant="outline" onClick={() => signOut()}>خروج</Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground" dir="rtl">
      <div className="grid min-h-screen lg:grid-cols-[260px_1fr]">
        <aside className="border-b border-border bg-card lg:border-b-0 lg:border-l">
          <div className="flex items-center justify-between px-4 py-4 lg:block">
            <div>
              <p className="text-xs text-primary">لوحة إدارة</p>
              <p className="font-bold">الدكتور نيوز</p>
            </div>
            <Button variant="ghost" size="icon" onClick={() => signOut()} aria-label="خروج"><LogOut /></Button>
          </div>
          <nav className="flex gap-2 overflow-x-auto px-4 pb-4 lg:grid lg:overflow-visible">
            <Link to="/" className="inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-secondary"><Home className="h-4 w-4" />الموقع</Link>
            <Link to="/admin" className="inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-secondary"><FileText className="h-4 w-4" />نظرة عامة</Link>
            <Link to="/admin/articles" className="inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-secondary"><FileText className="h-4 w-4" />المقالات</Link>
            <Link to="/admin/articles/new" className="inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-secondary"><Plus className="h-4 w-4" />إضافة</Link>
            {isAdmin && <Link to="/admin/team" className="inline-flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-secondary"><Users className="h-4 w-4" />الفريق</Link>}
          </nav>
        </aside>
        <section className="min-w-0 px-4 py-6 sm:px-6 lg:px-8">{children}</section>
      </div>
    </div>
  );
}
