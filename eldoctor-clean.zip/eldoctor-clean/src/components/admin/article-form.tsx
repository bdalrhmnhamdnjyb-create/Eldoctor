import { useEffect, useState, type FormEvent } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Save, UploadCloud } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import type { Article, ArticleStatus, Category } from "@/lib/news";
import { excerptFromContent, makeSlug } from "@/lib/news";

type FormState = {
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category_id: string;
  status: ArticleStatus;
  is_featured: boolean;
  cover_image_url: string;
  video_url: string;
};

export function ArticleForm({ article }: { article?: Article }) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [categories, setCategories] = useState<Category[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [state, setState] = useState<FormState>({
    title: article?.title ?? "",
    slug: article?.slug ?? "",
    excerpt: article?.excerpt ?? "",
    content: article?.content ?? "",
    category_id: article?.category_id ?? "",
    status: article?.status ?? "draft",
    is_featured: article?.is_featured ?? false,
    cover_image_url: article?.cover_image_url ?? "",
    video_url: article?.video_url ?? "",
  });

  useEffect(() => {
    supabase.from("categories").select("*").order("sort_order").then(({ data }) => {
      const list = data ?? [];
      setCategories(list);
      if (!state.category_id && list[0]) setState((current) => ({ ...current, category_id: list[0].id }));
    });
  }, []);

  const uploadCover = async (file: File) => {
    setError("");
    const ext = file.name.split(".").pop() || "jpg";
    const path = `${user?.id}/${Date.now()}.${ext}`;
    const { error: uploadError } = await supabase.storage.from("article-media").upload(path, file, { upsert: false });
    if (uploadError) {
      setError("تعذر رفع الصورة. تأكد من صلاحيات حسابك.");
      return;
    }
    setState((current) => ({ ...current, cover_image_url: path }));
  };

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!user) return;
    setSaving(true);
    setError("");

    const payload = {
      title: state.title.trim(),
      slug: (state.slug || makeSlug(state.title)).trim(),
      excerpt: (state.excerpt || excerptFromContent(state.content)).trim(),
      content: state.content.trim(),
      category_id: state.category_id,
      status: state.status,
      is_featured: state.is_featured,
      cover_image_url: state.cover_image_url.trim() || null,
      video_url: state.video_url.trim() || null,
    };

    const result = article
      ? await supabase.from("articles").update(payload).eq("id", article.id)
      : await supabase.from("articles").insert({ ...payload, author_id: user.id });

    setSaving(false);
    if (result.error) {
      setError(result.error.message.includes("duplicate") ? "الرابط مستخدم من قبل، غيّر رابط المقال." : "لم يتم الحفظ. راجع البيانات والصلاحيات.");
      return;
    }
    navigate({ to: "/admin/articles" });
  };

  return (
    <form onSubmit={submit} className="grid gap-5">
      {error && <div className="rounded-md border border-destructive bg-destructive/10 px-4 py-3 text-sm text-destructive">{error}</div>}
      <div className="grid gap-2">
        <Label htmlFor="title">العنوان</Label>
        <Input id="title" value={state.title} onChange={(e) => setState({ ...state, title: e.target.value, slug: state.slug || makeSlug(e.target.value) })} required minLength={5} maxLength={160} />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="slug">رابط المقال</Label>
        <Input id="slug" dir="ltr" value={state.slug} onChange={(e) => setState({ ...state, slug: makeSlug(e.target.value) })} required />
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="grid gap-2">
          <Label htmlFor="category">القسم</Label>
          <select id="category" value={state.category_id} onChange={(e) => setState({ ...state, category_id: e.target.value })} className="h-9 rounded-md border border-input bg-background px-3 text-sm">
            {categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}
          </select>
        </div>
        <div className="grid gap-2">
          <Label htmlFor="status">حالة النشر</Label>
          <select id="status" value={state.status} onChange={(e) => setState({ ...state, status: e.target.value as ArticleStatus })} className="h-9 rounded-md border border-input bg-background px-3 text-sm">
            <option value="draft">مسودة</option>
            <option value="published">منشور</option>
          </select>
        </div>
      </div>
      <div className="grid gap-2">
        <Label htmlFor="excerpt">ملخص قصير</Label>
        <Textarea id="excerpt" value={state.excerpt} onChange={(e) => setState({ ...state, excerpt: e.target.value })} maxLength={320} />
      </div>
      <div className="grid gap-2">
        <Label htmlFor="content">المحتوى</Label>
        <Textarea id="content" className="min-h-72 leading-7" value={state.content} onChange={(e) => setState({ ...state, content: e.target.value })} required />
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="grid gap-2">
          <Label htmlFor="cover">صورة رئيسية</Label>
          <Input id="cover" type="file" accept="image/*" onChange={(e) => { const file = e.target.files?.[0]; if (file) uploadCover(file); }} />
          {state.cover_image_url && <p className="text-xs text-muted-foreground">تم اختيار: {state.cover_image_url}</p>}
        </div>
        <div className="grid gap-2">
          <Label htmlFor="video">رابط فيديو اختياري</Label>
          <Input id="video" dir="ltr" value={state.video_url} onChange={(e) => setState({ ...state, video_url: e.target.value })} />
        </div>
      </div>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" checked={state.is_featured} onChange={(e) => setState({ ...state, is_featured: e.target.checked })} />
        مقال مميز في الصفحة الرئيسية
      </label>
      <div className="flex gap-3">
        <Button type="submit" disabled={saving}><Save />{saving ? "جاري الحفظ" : "حفظ المقال"}</Button>
        <Button type="button" variant="outline" onClick={() => document.getElementById("cover")?.click()}><UploadCloud />رفع صورة</Button>
      </div>
    </form>
  );
}
