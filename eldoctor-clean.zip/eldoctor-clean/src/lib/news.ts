import type { Database } from "@/integrations/supabase/types";

export type Category = Database["public"]["Tables"]["categories"]["Row"];
export type Article = Database["public"]["Tables"]["articles"]["Row"] & {
  categories?: Pick<Category, "name" | "slug" | "kind"> | null;
};
export type ArticleStatus = Database["public"]["Enums"]["article_status"];
export type AppRole = Database["public"]["Enums"]["app_role"];

export const roleLabels: Record<AppRole, string> = {
  admin: "مدير",
  moderator: "مشرف",
  editor: "كاتب",
};

export const statusLabels: Record<ArticleStatus, string> = {
  draft: "مسودة",
  published: "منشور",
};

export function formatArabicDate(value?: string | null) {
  if (!value) return "غير منشور";
  return new Intl.DateTimeFormat("ar-EG", { dateStyle: "medium" }).format(new Date(value));
}

export function makeSlug(value: string) {
  const normalized = value
    .trim()
    .toLowerCase()
    .replace(/[أإآ]/g, "a")
    .replace(/[ءؤئ]/g, "e")
    .replace(/[ة]/g, "h")
    .replace(/[ى]/g, "a")
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
  return normalized || `article-${Date.now()}`;
}

export function excerptFromContent(content: string) {
  return content.replace(/\s+/g, " ").trim().slice(0, 220);
}
