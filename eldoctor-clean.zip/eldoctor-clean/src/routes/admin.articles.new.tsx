import { createFileRoute } from "@tanstack/react-router";
import { AdminLayout } from "@/components/admin/admin-layout";
import { ArticleForm } from "@/components/admin/article-form";
export const Route = createFileRoute("/admin/articles/new")({ component: NewArticle });
function NewArticle(){return <AdminLayout><h1 className="mb-6 text-3xl font-bold">إضافة مقال جديد</h1><ArticleForm /></AdminLayout>}
