import { createFileRoute, Link, Outlet, useLocation } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { AdminLayout } from "@/components/admin/admin-layout";
export const Route = createFileRoute("/admin")({ component: AdminHome });
function AdminHome(){const location=useLocation();if(location.pathname!=="/admin")return <Outlet />;return <AdminLayout><div className="max-w-4xl"><p className="text-primary">مرحبا بك</p><h1 className="text-3xl font-bold">لوحة إدارة المجلة</h1><p className="mt-3 text-muted-foreground">من هنا يمكنك إضافة الأخبار والمقالات وتعديلها وحذفها وإدارة الفريق.</p><div className="mt-6 flex gap-3"><Button asChild><Link to="/admin/articles/new">إضافة مقال</Link></Button><Button variant="outline" asChild><Link to="/admin/articles">إدارة المقالات</Link></Button></div></div></AdminLayout>}
