import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteLayout } from "@/components/news/site-layout";
import { Input } from "@/components/ui/input";
import { ArticleCard } from "@/components/news/article-card";
import { supabase } from "@/integrations/supabase/client";
import type { Article } from "@/lib/news";
export const Route = createFileRoute("/search")({ component: SearchPage });
function SearchPage() { const [items,setItems]=useState<Article[]>([]); const search=(q:string)=>{ if(q.length<2){setItems([]);return;} supabase.from("articles").select("*, categories(name, slug, kind)").eq("status","published").or(`title.ilike.%${q}%,excerpt.ilike.%${q}%,content.ilike.%${q}%`).limit(20).then(({data})=>setItems((data??[]) as Article[]));}; return <SiteLayout><section className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8"><h1 className="mb-6 text-3xl font-bold">البحث</h1><Input placeholder="ابحث في الأخبار والمقالات" onChange={(e)=>search(e.target.value)} /><div className="mt-8 grid gap-6">{items.map((a)=><ArticleCard key={a.id} article={a}/>)}</div></section></SiteLayout>; }
