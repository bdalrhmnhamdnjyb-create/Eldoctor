import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import logo from "@/assets/dr-ahmed-logo.jpg";

export const Route = createFileRoute("/login")({ component: LoginPage });

function LoginPage() {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [message, setMessage] = useState("");

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setMessage("");
    const result = mode === "login"
      ? await supabase.auth.signInWithPassword({ email, password })
      : await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin, data: { full_name: name } } });
    if (result.error) setMessage("تعذر إتمام العملية. راجع البريد وكلمة المرور.");
    else if (mode === "signup") setMessage("تم إنشاء الحساب. افحص بريدك إذا طُلب التأكيد.");
    else navigate({ to: "/admin" });
  };

  const signInWithGoogle = async () => {
    setMessage("");
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: `${window.location.origin}/admin` });
    if (result.error) setMessage("تعذر فتح تسجيل الدخول عبر Google. جرّب البريد وكلمة المرور.");
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4 text-foreground" dir="rtl">
      <form onSubmit={submit} className="w-full max-w-md rounded-md border border-border bg-card p-6 shadow-[var(--shadow-elegant)]">
        <img src={logo} alt="شعار الدكتور نيوز" className="mx-auto mb-4 h-20 w-20 rounded-md object-cover" />
        <h1 className="text-center text-2xl font-bold">دخول لوحة الإدارة</h1>
        <div className="mt-6 grid gap-4">
          {mode === "signup" && <div className="grid gap-2"><Label htmlFor="name">الاسم</Label><Input id="name" value={name} onChange={(e)=>setName(e.target.value)} required /></div>}
          <div className="grid gap-2"><Label htmlFor="email">البريد الإلكتروني</Label><Input id="email" type="email" value={email} onChange={(e)=>setEmail(e.target.value)} required /></div>
          <div className="grid gap-2"><Label htmlFor="password">كلمة المرور</Label><Input id="password" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} required minLength={6} /></div>
          {message && <p className="text-sm text-primary">{message}</p>}
          <Button type="submit">{mode === "login" ? "تسجيل الدخول" : "إنشاء حساب"}</Button>
          <Button type="button" variant="outline" onClick={signInWithGoogle}>الدخول باستخدام Google</Button>
          <Button type="button" variant="ghost" onClick={() => setMode(mode === "login" ? "signup" : "login")}>{mode === "login" ? "إنشاء حساب جديد" : "لدي حساب بالفعل"}</Button>
          <Link to="/" className="text-center text-sm text-muted-foreground hover:text-primary">العودة للموقع</Link>
        </div>
      </form>
    </div>
  );
}
