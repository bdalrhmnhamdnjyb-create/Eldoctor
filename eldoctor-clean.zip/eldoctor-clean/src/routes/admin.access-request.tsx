import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";

export const Route = createFileRoute("/admin/access-request")({ component: AccessRequestPage });

function AccessRequestPage() {
  const { user, signOut } = useAuth();
  const [message, setMessage] = useState("جاري تجهيز طلبك...");

  useEffect(() => {
    if (!user) return;

    const createRequest = async () => {
      const displayName = user.user_metadata?.full_name || user.user_metadata?.name || user.email || "مستخدم جديد";
      const { error } = await (supabase.from("admin_access_requests" as never) as any).upsert(
        {
          user_id: user.id,
          display_name: displayName,
          email: user.email ?? "",
          requested_role: "editor",
          status: "pending",
        },
        { onConflict: "user_id" },
      );
      setMessage(error ? "تعذر إرسال الطلب. حاول مرة أخرى." : "تم إرسال طلبك للمدير. انتظر الموافقة ثم ادخل مرة أخرى.");
    };

    createRequest();
  }, [user]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4 text-foreground" dir="rtl">
      <div className="max-w-md rounded-md border border-border bg-card p-6 text-center shadow-[var(--shadow-elegant)]">
        <h1 className="text-2xl font-bold">طلب دخول الإدارة</h1>
        <p className="mt-3 text-sm leading-7 text-muted-foreground">{message}</p>
        <Button className="mt-6" variant="outline" onClick={() => signOut()}>خروج</Button>
      </div>
    </div>
  );
}