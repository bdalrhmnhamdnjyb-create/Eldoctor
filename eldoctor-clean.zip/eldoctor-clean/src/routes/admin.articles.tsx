import { createFileRoute, Link, Outlet, useLocation } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Edit, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AdminLayout } from "@/components/admin/admin-layout";
import { supabase } from "@/integrations/supabase/client";
import type { Article } from "@/lib/news";
import { formatArabicDate, statusLabels } from "@/lib/news";
export const Route = createFileRoute("/admin/articles")({ component: AdminArticles });
function AdminArticles(){const location=useLocation();const[items,setItems]=useState<Article[]>([]);const load=()=>supabase.from("articles").select("*, categories(name, slug, kind)").order("created_at",{ascending:false}).then(({data})=>setItems((data??[]) as Article[]));useEffect(()=>{load();},[]);const del=async(id:string)=>{if(confirm("حذف المقال؟")){await supabase.from("articles").delete().eq("id",id);load();}};if(location.pathname!=="/admin/articles")return <Outlet />;return <AdminLayout><div className="mb-6 flex items-center justify-between"><h1 className="text-3xl font-bold">المقالات</h1><Button asChild><Link to="/admin/articles/new">إضافة مقال</Link></Button></div><div className="grid gap-3">{items.map(a=><div key={a.id} className="grid gap-3 rounded-md border border-border bg-card p-4 sm:grid-cols-[1fr_auto]"><div><p className="font-bold">{a.title}</p><p className="mt-1 text-sm text-muted-foreground">{a.categories?.name} · {statusLabels[a.status]} · {formatArabicDate(a.published_at??a.created_at)}</p></div><div className="flex gap-2"><Button variant="outline" size="sm" asChild><Link to="/admin/articles/$id/edit" params={{id:a.id}}><Edit />تعديل</Link></Button><Button variant="destructive" size="sm" onClick={()=>del(a.id)}><Trash2 />حذف</Button></div></div>)}</div></AdminLayout>}
