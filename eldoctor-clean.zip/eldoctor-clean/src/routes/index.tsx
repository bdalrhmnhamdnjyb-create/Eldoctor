import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Crown, Mail, Newspaper, PenTool, PlayCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { SiteLayout } from "@/components/news/site-layout";
import { ArticleCard } from "@/components/news/article-card";
import type { Article, Category } from "@/lib/news";
import logo from "@/assets/dr-ahmed-logo.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "الدكتور نيوز | مجلة أخبار ومقالات" },
      { name: "description", content: "مجلة فاخرة للأخبار والمقالات والتصميم والمحتوى المرئي بإدارة الدكتور نيوز." },
      { property: "og:title", content: "الدكتور نيوز | مجلة أخبار ومقالات" },
      { property: "og:description", content: "تابع أحدث الأخبار والمقالات والتصميم والمحتوى المرئي." },
    ],
  }),
  component: Index,
});

function useSignedUrls(articles: Article[]) {
  const [urls, setUrls] = useState<Record<string, string>>({});
  useEffect(() => {
    Promise.all(
      articles.map(async (article) => {
        if (!article.cover_image_url) return [article.id, ""] as const;
        if (article.cover_image_url.startsWith("http")) return [article.id, article.cover_image_url] as const;
        const { data } = await supabase.storage.from("article-media").createSignedUrl(article.cover_image_url, 60 * 60);
        return [article.id, data?.signedUrl ?? ""] as const;
      }),
    ).then((entries) => setUrls(Object.fromEntries(entries)));
  }, [articles]);
  return urls;
}

function Index() {
  const [articles, setArticles] = useState<Article[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const urls = useSignedUrls(articles);

  useEffect(() => {
    supabase.from("articles").select("*, categories(name, slug, kind)").eq("status", "published").order("is_featured", { ascending: false }).order("published_at", { ascending: false }).limit(7).then(({ data }) => setArticles((data ?? []) as Article[]));
    supabase.from("categories").select("*").order("sort_order").then(({ data }) => setCategories(data ?? []));
  }, []);

  const featured = articles[0];
  const rest = articles.slice(1);

  return (
    <SiteLayout>
      <section className="border-b border-border bg-[radial-gradient(circle_at_top,var(--secondary),var(--background)_55%)]">
        <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:px-8 lg:py-14">
          <div className="flex items-center justify-center lg:order-2">
            <img src={logo} alt="شعار الدكتور نيوز" className="h-56 w-56 rounded-md border border-primary/40 object-cover shadow-[var(--shadow-elegant)] sm:h-72 sm:w-72" />
          </div>
          <div className="flex flex-col justify-center lg:order-1">
            <div className="mb-4 inline-flex w-fit items-center gap-2 rounded-sm border border-primary/30 bg-primary/10 px-3 py-1 text-sm text-primary"><Crown className="h-4 w-4" /> مجلة أخبار ومقالات</div>
            <h1 className="text-4xl font-extrabold leading-tight sm:text-5xl lg:text-6xl">الدكتور نيوز</h1>
            <p className="mt-4 max-w-2xl text-base leading-8 text-muted-foreground sm:text-lg">موقع عربي للأخبار والمقالات والرأي والتصميم والمحتوى المرئي، بإدارة تحريرية موثوقة.</p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Button asChild><Link to="/articles">تصفح المقالات <ArrowLeft /></Link></Button>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="mb-6 flex items-end justify-between gap-4">
          <div>
            <p className="text-sm text-primary">الأحدث الآن</p>
            <h2 className="text-2xl font-bold">أخبار ومقالات مختارة</h2>
          </div>
          <Link to="/articles" className="text-sm text-primary hover:underline">عرض الكل</Link>
        </div>
        {featured ? (
          <div className="grid gap-6 lg:grid-cols-[1.3fr_0.7fr]">
            <ArticleCard article={featured} imageUrl={urls[featured.id]} featured />
            <div className="grid gap-5">
              {rest.slice(0, 3).map((article) => <ArticleCard key={article.id} article={article} imageUrl={urls[article.id]} />)}
            </div>
          </div>
        ) : (
          <div className="rounded-md border border-border bg-card p-8 text-center text-muted-foreground">ابدأ من لوحة الإدارة بنشر أول خبر أو مقال.</div>
        )}
      </section>

      <section className="border-t border-border bg-card">
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {categories.map((category, index) => {
              const icons = [Newspaper, PenTool, Crown, PlayCircle];
              const Icon = icons[index] ?? Newspaper;
              return (
                <Link key={category.id} to="/categories/$slug" params={{ slug: category.slug }} className="rounded-md border border-border bg-background p-5 transition-colors hover:border-primary/50">
                  <Icon className="mb-4 h-7 w-7 text-primary" />
                  <h3 className="font-bold">{category.name}</h3>
                  <p className="mt-2 text-sm leading-7 text-muted-foreground">{category.description}</p>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      <section className="border-t border-border">
        <div className="mx-auto max-w-3xl px-4 py-12 text-center sm:px-6 lg:px-8">
          <div className="mb-4 inline-flex items-center gap-2 rounded-sm border border-primary/30 bg-primary/10 px-3 py-1 text-sm text-primary">
            <Mail className="h-4 w-4" /> اشترك في النشرة الإخبارية
          </div>
          <h2 className="text-2xl font-bold sm:text-3xl">اشترك في النشرة الإخبارية</h2>
          <p className="mt-3 text-muted-foreground">أدخل بريدك الإلكتروني وستصلك آخر الأخبار والمقالات أولاً بأول.</p>
          <form
            action="https://formsubmit.co/bdalrhmnhamdnjyb@gmail.com"
            method="POST"
            className="mx-auto mt-6 flex max-w-xl flex-col gap-3 sm:flex-row"
          >
            <input type="hidden" name="_subject" value="اشتراك جديد في النشرة الإخبارية" />
            <input type="hidden" name="_captcha" value="false" />
            <input type="hidden" name="_template" value="table" />
            <input type="hidden" name="_next" value={typeof window !== "undefined" ? window.location.origin + "/?subscribed=1" : "/"} />
            <Input
              type="email"
              name="email"
              required
              placeholder="بريدك الإلكتروني"
              className="flex-1"
              dir="ltr"
            />
            <Input
              type="text"
              name="name"
              placeholder="الاسم (اختياري)"
              className="flex-1"
            />
            <Button type="submit">اشترك الآن</Button>
          </form>
        </div>
      </section>
    </SiteLayout>
  );
}
