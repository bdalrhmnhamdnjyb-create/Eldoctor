import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout } from "@/components/news/site-layout";
import { ArticleCard } from "@/components/news/article-card";
import { supabase } from "@/integrations/supabase/client";
import type { Article, Category } from "@/lib/news";

export const Route = createFileRoute("/categories/$slug")({ component: CategoryPage });
function CategoryPage() {
  const { slug } = Route.useParams();
  const [category, setCategory] = useState<Category | null>(null);
  const [articles, setArticles] = useState<Article[]>([]);
  useEffect(() => { supabase.from("categories").select("*").eq("slug", slug).maybeSingle().then(async ({ data }) => { setCategory(data); if (data) { const res = await supabase.from("articles").select("*, categories(name, slug, kind)").eq("category_id", data.id).eq("status", "published").order("published_at", { ascending: false }); setArticles((res.data ?? []) as Article[]); } }); }, [slug]);
  return <SiteLayout><section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8"><p className="text-primary">قسم</p><h1 className="text-3xl font-bold">{category?.name ?? "القسم"}</h1><p className="mt-3 text-muted-foreground">{category?.description}</p><div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{articles.map((article) => <ArticleCard key={article.id} article={article} />)}</div></section></SiteLayout>;
}
