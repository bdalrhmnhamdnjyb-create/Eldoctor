import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout } from "@/components/news/site-layout";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import type { Article } from "@/lib/news";
import { formatArabicDate } from "@/lib/news";

export const Route = createFileRoute("/articles/$slug")({ component: ArticlePage });

function getVideoEmbedUrl(url?: string | null) {
  if (!url) return "";
  try {
    const parsed = new URL(url);
    if (parsed.hostname.includes("youtube.com")) {
      const id = parsed.searchParams.get("v") || parsed.pathname.split("/").filter(Boolean).pop();
      return id ? `https://www.youtube.com/embed/${id}` : url;
    }
    if (parsed.hostname.includes("youtu.be")) {
      const id = parsed.pathname.split("/").filter(Boolean)[0];
      return id ? `https://www.youtube.com/embed/${id}` : url;
    }
    if (parsed.hostname.includes("vimeo.com")) {
      const id = parsed.pathname.split("/").filter(Boolean).pop();
      return id ? `https://player.vimeo.com/video/${id}` : url;
    }
    return url;
  } catch {
    return "";
  }
}

function ArticlePage() {
  const { slug } = Route.useParams();
  const [article, setArticle] = useState<Article | null>(null);
  const [image, setImage] = useState("");
  const videoEmbedUrl = getVideoEmbedUrl(article?.video_url);
  useEffect(() => {
    supabase.from("articles").select("*, categories(name, slug, kind)").eq("slug", slug).eq("status", "published").maybeSingle().then(async ({ data }) => {
      const item = data as Article | null;
      setArticle(item);
      if (item?.cover_image_url) {
        if (item.cover_image_url.startsWith("http")) setImage(item.cover_image_url);
        else {
          const { data } = await supabase.storage.from("article-media").createSignedUrl(item.cover_image_url, 3600);
          setImage(data?.signedUrl ?? "");
        }
      }
    });
  }, [slug]);
  return <SiteLayout><article className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">{article ? <><div className="mb-4 text-sm text-primary">{article.categories?.name} · {formatArabicDate(article.published_at ?? article.created_at)}</div><h1 className="text-3xl font-extrabold leading-tight sm:text-5xl">{article.title}</h1>{article.excerpt && <p className="mt-4 text-lg leading-8 text-muted-foreground">{article.excerpt}</p>}{image && <img src={image} alt={article.title} className="my-8 aspect-[16/9] w-full rounded-md object-cover" />}<div className="whitespace-pre-wrap text-lg leading-10">{article.content}</div>{videoEmbedUrl && <div className="mt-8 overflow-hidden rounded-md border border-border bg-card"><iframe src={videoEmbedUrl} title={`فيديو ${article.title}`} className="aspect-video w-full" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowFullScreen /></div>}</> : <><h1 className="text-2xl font-bold">المقال غير موجود</h1><Button className="mt-6" asChild><Link to="/articles">عودة للمقالات</Link></Button></>}</article></SiteLayout>;
}
