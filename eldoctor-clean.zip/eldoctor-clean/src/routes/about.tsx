import { createFileRoute } from "@tanstack/react-router";
import { Mail, Phone, MapPin, Calendar, Award, BookOpen, Sparkles } from "lucide-react";
import { SiteLayout } from "@/components/news/site-layout";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import profileImage from "@/assets/ahmed-hamed-profile.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "من نحن — الدكتور نيوز" },
      { name: "description", content: "تعرّف على أحمد حامد نجيب، أخصائي الإعلام ومؤسس مجلة الدكتور نيوز." },
      { property: "og:title", content: "من نحن — الدكتور نيوز" },
      { property: "og:description", content: "تعرّف على أحمد حامد نجيب، أخصائي الإعلام ومؤسس مجلة الدكتور نيوز." },
    ],
  }),
  component: AboutPage,
});

const skills = [
  { name: "التواصل والإلقاء", desc: "مهارات قوية في التواصل الشفهي والكتابي مع جمهور متنوع." },
  { name: "إدارة وسائل التواصل الاجتماعي", desc: "تخطيط المحتوى وتحليل التفاعل عبر فيسبوك وإنستجرام وتيك توك." },
  { name: "Adobe After Effects", desc: "إنشاء موشن جرافيك ومؤثرات بصرية ورسوم متحركة احترافية." },
  { name: "صناعة المحتوى", desc: "إنتاج محتوى مكتوب ومرئي جذاب مخصص للجمهور المستهدف." },
  { name: "التصوير والمونتاج", desc: "التقاط ومعالجة الصور والفيديوهات بمعدات وبرامج احترافية." },
];

const awards = [
  { title: "جائزة أفضل مقدِّم", org: "نادي المناظرات الجامعي", date: "23/09/2023", desc: "تكريم للتميّز في الإلقاء وإشراك الجمهور خلال المنافسات الجامعية." },
  { title: "جائزة أفضل مشروع إعلامي", org: "كلية التربية النوعية - قسم الإعلام", date: "03/05/2022", desc: "عن مشروع تخرج جمع بين المونتاج والتصميم الصوتي والسرد الإبداعي." },
  { title: "تميُّز حملة على وسائل التواصل", org: "مبادرة شباب الإعلام", date: "14/11/2024", desc: "قيادة حملة توعوية ناجحة حقّقت تفاعلاً ووصولاً عاليًا." },
];

const courses = [
  { title: "مقدمة في الخطابة العامة", org: "edX – جامعة واشنطن", date: "10/2024 – 12/2024" },
  { title: "إنتاج الإعلام الرقمي", org: "Coursera – جامعة إلينوي", date: "2023" },
  { title: "التسويق عبر وسائل التواصل", org: "Meta عبر Coursera", date: "2021" },
];

function AboutPage() {
  return (
    <SiteLayout>
      <div dir="rtl" className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
        {/* Hero */}
        <section className="grid gap-8 md:grid-cols-[auto_1fr] md:items-center">
          <div className="mx-auto md:mx-0">
            <div className="relative">
              <div className="absolute -inset-2 rounded-full bg-gradient-to-tr from-primary/30 to-primary/5 blur-xl" />
              <img
                src={profileImage}
                alt="أحمد حامد نجيب"
                className="relative h-44 w-44 rounded-full border-4 border-primary/30 object-cover shadow-xl sm:h-56 sm:w-56"
              />
            </div>
          </div>
          <div className="text-center md:text-right">
            <Badge className="mb-3">من نحن</Badge>
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">أحمد حامد نجيب</h1>
            <p className="mt-2 text-lg text-primary">أخصائي إعلام ومؤسس مجلة الدكتور نيوز</p>
            <p className="mt-4 leading-8 text-muted-foreground">
              خرّيج كلية التربية النوعية - قسم الإعلام، يمتلك أساسًا قويًا في التواصل وصناعة المحتوى
              والإنتاج الإعلامي. شغوف بإيصال الرسائل المؤثرة وإشراك الجمهور عبر السرد الإبداعي،
              ويسعى لتقديم محتوى عربي راقٍ يجمع بين الأخبار والتصميم والإبداع.
            </p>
          </div>
        </section>

        {/* Contact */}
        <section className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Card className="flex items-center gap-3 p-4">
            <Mail className="h-5 w-5 text-primary" />
            <a href="mailto:ahmedhamednaguib@gmail.com" className="truncate text-sm hover:text-primary">
              ahmedhamednaguib@gmail.com
            </a>
          </Card>
          <Card className="flex items-center gap-3 p-4">
            <Phone className="h-5 w-5 text-primary" />
            <a href="tel:01125523580" className="text-sm hover:text-primary" dir="ltr">01125523580</a>
          </Card>
          <Card className="flex items-center gap-3 p-4">
            <MapPin className="h-5 w-5 text-primary" />
            <span className="text-sm">المنيا - البرجاية</span>
          </Card>
          <Card className="flex items-center gap-3 p-4">
            <Calendar className="h-5 w-5 text-primary" />
            <span className="text-sm">18/9/2004 - مصري</span>
          </Card>
        </section>

        {/* Skills */}
        <section className="mt-12">
          <div className="mb-6 flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            <h2 className="text-2xl font-bold">المهارات</h2>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {skills.map((s) => (
              <Card key={s.name} className="p-5">
                <h3 className="font-semibold">{s.name}</h3>
                <p className="mt-2 text-sm leading-7 text-muted-foreground">{s.desc}</p>
              </Card>
            ))}
          </div>
        </section>

        {/* Awards */}
        <section className="mt-12">
          <div className="mb-6 flex items-center gap-2">
            <Award className="h-5 w-5 text-primary" />
            <h2 className="text-2xl font-bold">الجوائز والإنجازات</h2>
          </div>
          <div className="grid gap-4">
            {awards.map((a) => (
              <Card key={a.title} className="p-5">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <h3 className="font-semibold">{a.title}</h3>
                  <span className="text-xs text-muted-foreground">{a.date}</span>
                </div>
                <p className="mt-1 text-sm text-primary">{a.org}</p>
                <p className="mt-2 text-sm leading-7 text-muted-foreground">{a.desc}</p>
              </Card>
            ))}
          </div>
        </section>

        {/* Courses */}
        <section className="mt-12">
          <div className="mb-6 flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-primary" />
            <h2 className="text-2xl font-bold">الدورات التدريبية</h2>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {courses.map((c) => (
              <Card key={c.title} className="p-5">
                <h3 className="font-semibold">{c.title}</h3>
                <p className="mt-2 text-sm text-primary">{c.org}</p>
                <p className="mt-1 text-xs text-muted-foreground">{c.date}</p>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </SiteLayout>
  );
}
