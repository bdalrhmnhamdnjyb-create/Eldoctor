import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AdminLayout } from "@/components/admin/admin-layout";
import { ArticleForm } from "@/components/admin/article-form";
import { supabase } from "@/integrations/supabase/client";
import type { Article } from "@/lib/news";
export const Route = createFileRoute("/admin/articles/$id/edit")({ component: EditArticle });
function EditArticle(){const{id}=Route.useParams();const[article,setArticle]=useState<Article|null>(null);useEffect(()=>{supabase.from("articles").select("*, categories(name, slug, kind)").eq("id",id).maybeSingle().then(({data})=>setArticle(data as Article|null));},[id]);return <AdminLayout><h1 className="mb-6 text-3xl font-bold">تعديل المقال</h1>{article?<ArticleForm article={article}/>:<p>جاري التحميل...</p>}</AdminLayout>}
