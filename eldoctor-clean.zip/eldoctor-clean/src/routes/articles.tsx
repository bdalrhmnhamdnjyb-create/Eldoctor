import { createFileRoute, Outlet, useLocation } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SiteLayout } from "@/components/news/site-layout";
import { ArticleCard } from "@/components/news/article-card";
import { supabase } from "@/integrations/supabase/client";
import type { Article } from "@/lib/news";

export const Route = createFileRoute("/articles")({ component: ArticlesPage });

function ArticlesPage() {
  const location = useLocation();
  const [articles, setArticles] = useState<Article[]>([]);
  const [urls, setUrls] = useState<Record<string, string>>({});
  useEffect(() => {
    supabase.from("articles").select("*, categories(name, slug, kind)").eq("status", "published").order("published_at", { ascending: false }).then(async ({ data }) => {
      const list = (data ?? []) as Article[];
      setArticles(list);
      const entries = await Promise.all(list.map(async (a) => {
        if (!a.cover_image_url) return [a.id, ""] as const;
        if (a.cover_image_url.startsWith("http")) return [a.id, a.cover_image_url] as const;
        const { data } = await supabase.storage.from("article-media").createSignedUrl(a.cover_image_url, 3600);
        return [a.id, data?.signedUrl ?? ""] as const;
      }));
      setUrls(Object.fromEntries(entries));
    });
  }, []);
  if (location.pathname !== "/articles") return <Outlet />;

  return <SiteLayout><section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8"><h1 className="mb-8 text-3xl font-bold">كل الأخبار والمقالات</h1><div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{articles.map((article) => <ArticleCard key={article.id} article={article} imageUrl={urls[article.id]} />)}</div></section></SiteLayout>;
}
