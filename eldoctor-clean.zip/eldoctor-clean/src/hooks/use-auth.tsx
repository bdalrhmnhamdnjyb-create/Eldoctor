import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type AppRole = Database["public"]["Enums"]["app_role"];

type AuthContextValue = {
  user: User | null;
  session: Session | null;
  roles: AppRole[];
  loading: boolean;
  isTeamMember: boolean;
  isAdmin: boolean;
  canClaimFirstAdmin: boolean;
  refreshRoles: () => Promise<void>;
  claimFirstAdmin: () => Promise<boolean>;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

async function loadRoles(userId: string): Promise<AppRole[]> {
  const { data, error } = await supabase.from("user_roles").select("role").eq("user_id", userId);
  if (error) return [];
  return (data ?? []).map((item) => item.role);
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [roles, setRoles] = useState<AppRole[]>([]);
  const [loading, setLoading] = useState(true);

  const refreshRoles = async () => {
    if (!user) {
      setRoles([]);
      return;
    }
    setRoles(await loadRoles(user.id));
  };

  useEffect(() => {
    const { data: subscription } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      setUser(nextSession?.user ?? null);
      if (nextSession?.user) {
        setTimeout(() => {
          loadRoles(nextSession.user.id).then(setRoles);
        }, 0);
      } else {
        setRoles([]);
      }
      setLoading(false);
    });

    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setUser(data.session?.user ?? null);
      if (data.session?.user) {
        loadRoles(data.session.user.id).then(setRoles).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    return () => subscription.subscription.unsubscribe();
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      user,
      session,
      roles,
      loading,
      isTeamMember: roles.length > 0,
      isAdmin: roles.includes("admin"),
      canClaimFirstAdmin: Boolean(
        user &&
          !roles.length &&
          (user.user_metadata?.full_name?.includes("عبدالرحمن") ||
            user.user_metadata?.name?.includes("عبدالرحمن") ||
            user.email?.toLowerCase().startsWith("abd")),
      ),
      refreshRoles,
      claimFirstAdmin: async () => {
        const { data, error } = await supabase.rpc("claim_first_admin");
        if (error || !data) return false;
        await refreshRoles();
        return true;
      },
      signOut: async () => {
        await supabase.auth.signOut();
      },
    }),
    [user, session, roles, loading],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used within AuthProvider");
  return context;
}
